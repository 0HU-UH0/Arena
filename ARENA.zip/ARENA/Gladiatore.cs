﻿using System;

namespace ARENA
{
    public class Gladiatore
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public int PuntiFerita { get; set; }
        public int DannoAttacco { get; set; }
        public int PercentualeDifesa { get; set; }

        private static Random random = new Random();

        public Gladiatore(int id)
        {
            Id = id;
            Nome = $"Gladiatore {id}";
            PuntiFerita = random.Next(50, 100); 
            DannoAttacco = random.Next(10, 20);  
            PercentualeDifesa = random.Next(20, 50); 
        }

        public void Attacca(Gladiatore difensore)
        {
            int danno = DannoAttacco;
            if (random.Next(100) < difensore.PercentualeDifesa)
            {
                int percentualeParata = random.Next(50, 101); 
                danno = danno * percentualeParata / 100;
            }

            difensore.PuntiFerita -= danno;
            if (difensore.PuntiFerita < 0)
                difensore.PuntiFerita = 0;
        }

        public bool IsVivo()
        {
            return PuntiFerita > 0;
        }

        public void RecuperaVita()
        {
            PuntiFerita = 100; 
        }
    }
}